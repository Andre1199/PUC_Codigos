﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace provaquestao1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Aluno: André Luiz Mendes Corrêa\n");
            double[,] numeros = new double[3, 3];
            double[] soma_coluna = new double[3];
            double soma = 0;
            try
            {
                for (int i = 0; i < numeros.GetLength(0); i++)
                {
                    for (int j = 0; j < numeros.GetLength(1); j++)
                    {
                        Console.Write("Insira um numero: ");
                        numeros[i, j] = double.Parse(Console.ReadLine());
                    }
                }
                Console.Clear();
                for (int i = 0; i < numeros.GetLength(0); i++)
                {
                    for (int j = 0; j < numeros.GetLength(1); j++)
                    {
                        numeros[i,j] = numeros[i, j] * 2;
                }
                    
                }
                for (int i = 0; i < numeros.GetLength(1); i++)
                {
                    for (int j = 0; j < numeros.GetLength(0); j++)
                    {
                       soma += numeros[i, j];
                    
                    }
                soma_coluna[i] = soma;
                Console.Write("O resultado da soma foi: "+soma_coluna[i]+"; ");
            }
                Console.ReadKey();
            }
            catch (Exception)
            {
                Console.Clear();
                Console.Write("Erro ao executar.");
            }
            finally
            {
                Console.Write("\nAperte ENTER para fechar o programa.");
                Console.ReadKey();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace questao2prova
{
    class Program
    {
        struct Controle
        {
             public int Matrícula;              public string Nome;
             public string Curso;
             public string Disciplina;
             public double Notafinal;
             public string Situação;
        }
         static public void Alunos(int tamanho, string nome, int matrícula, string curso, string disciplina, double notafinal, string situação)
        {
            Controle[] aluno = new Controle[tamanho];
            for (int i=0;i<tamanho;i++)
            {
                aluno[i].Nome = nome;
                aluno[i].Matrícula = matrícula;
                aluno[i].Curso = curso;
                aluno[i].Disciplina = disciplina;
                aluno[i].Notafinal = notafinal;
                aluno[i].Situação = situação;
            }
            Notas(aluno);
        }
        static void Notas(Controle [] vet)
        {
            double maior = int.MinValue;
            double menor = int.MaxValue;
            int alunoMaior=0, alunoMenor=0;
            for (int i=0;i<vet.Length;i++)
            {
                if (vet[i].Notafinal > maior)
                {
                    maior = vet[i].Notafinal;
                    alunoMaior = i;
                }
                if (vet[i].Notafinal < menor)
                {
                    menor = vet[i].Notafinal;
                    alunoMenor = i;
                }
            }
            Console.Write("A maior nota foi " + maior + " do aluno " + vet[alunoMaior].Nome+"\n");
            Console.Write("A menor nota foi " + menor + " do aluno " + vet[alunoMaior].Nome+"\n");
        }
        static void Main(string[] args)
        {
            Console.Write("Andre Luiz Mendes\n");
            int qtsAlunos, qtdAprovados = 0;
            int matrícula;             string nome, curso, disciplina, situação;
            double notafinal;

            Console.Write("Deseja inserir quantos alunos? ");
            qtsAlunos = int.Parse(Console.ReadLine());

            for (int i = 0; i < qtsAlunos; i++)
            {
                Console.Write("Insira o nome do aluno: ");
                nome = Console.ReadLine();
                Console.Write("Insira a matricula do aluno: ");
                matrícula = int.Parse(Console.ReadLine());
                Console.Write("Insira o curso do aluno: ");
                curso = Console.ReadLine();
                Console.Write("Insira a disciplina do aluno: ");
                disciplina = Console.ReadLine();
                Console.Write("Insira a nota final do aluno: ");
                notafinal = double.Parse(Console.ReadLine());
                Console.Write("Insira a situaçao do aluno: ");
                situação = Console.ReadLine();
                if (situação == "A")
                {
                    qtdAprovados++;
                }
                Alunos(qtsAlunos,nome,matrícula,curso,disciplina,notafinal,situação);
            }
            Console.Write("Foram aprovados " + qtdAprovados + " alunos.");
            Console.ReadKey();
        }
    }
}

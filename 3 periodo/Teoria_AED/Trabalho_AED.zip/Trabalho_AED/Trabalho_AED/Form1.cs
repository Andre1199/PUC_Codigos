﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trabalho_AED
{
    public partial class Form1 : Form
    {
        Banco banco;
        public Form1()
        {
            InitializeComponent();
            banco = new Banco();
            banco.LerArquivoDeClientes();
            banco._clientes.OrdenarLista();
            banco.LerArquivoDeContas();
            banco._contas.OrdenarLista();
            banco.LerArquivoDeOperações();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string dataPedida = maskedTextBox1.Text;
                string[] criadata = dataPedida.Split('/');
                DateTime teste = new DateTime(Convert.ToInt32(criadata[2]), Convert.ToInt32(criadata[1]), Convert.ToInt32(criadata[0]));
                ListaDeOperacao listaDataPedida = banco._operacoes.PesquisarData(teste);
                for (int i = 0; i < listaDataPedida.contador; i++)
                {
                    Operacao net = listaDataPedida.desenfileirar();
                    string[] nome = net.GetType().ToString().Split('.');
                    listBox1.Items.Add(net.valor + " , " + net.data.ToString("dd/MM/yyyy") + " , " + nome[1] + " , " + net.numConta);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Data invalida");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < banco._clientes.contador; i++)
                {
                    listBox1.Items.Add(banco._clientes.vetorClientes[i].nomeCliente + " , " + banco._clientes.vetorClientes[i].cpf);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < banco._contas.contador; i++)
                {
                    listBox1.Items.Add(banco._contas.vetorContas[i].cpfCliente + " , " + banco._contas.vetorContas[i].numConta + " , " + banco._contas.vetorContas[i].saldo.ToString("c"));
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Cliente novo = banco._clientes.BuscaBinaria("12335509");
            listBox1.Items.Add(novo.cpf + "," + novo.nomeCliente);

            novo = banco._clientes.BuscaBinaria("12335509");
            listBox1.Items.Add(novo.cpf + "," + novo.nomeCliente);

            novo = banco._clientes.BuscaBinaria("12335509");
            listBox1.Items.Add(novo.cpf + "," + novo.nomeCliente);
        }
    }
}

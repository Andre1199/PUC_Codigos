﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabalho_AED
{
    class ListaDeOperacao
    {
        private Operacao frente;
        private Operacao tras;
        public int contador;
        public ListaDeOperacao()
        {
            Operacao opera;
            opera = new Operacao();
            frente = opera;
            tras = opera;
            contador = 0;
        }

        public Boolean filaVazia()
        {
            if (frente == tras)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void enfileirar(Operacao opera)
        {
            tras.proximo = opera;
            tras = opera;
            contador++;
        }

        public Operacao desenfileirar()
        {
            Operacao opera = frente.proximo;

            if (!(filaVazia()))
            {
                frente.proximo = opera.proximo;
                opera.proximo = null;
                contador--;
            }
            return (opera);
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exerc_arvore
{
    class Program
    {
        static void Main(string[] args)
        {
            ArvoreBinariaAlunos classeDeAlunos = new ArvoreBinariaAlunos();
            Aluno a1 = new Aluno(123, "Joao", 9.7);
            classeDeAlunos.inserir(a1);
            Aluno a2 = new Aluno(456, "Maria", 8.7);
            classeDeAlunos.inserir(a2);
            Aluno a3 = new Aluno(789, "Marcos", 4.5);
            classeDeAlunos.inserir(a3);
            Aluno a4 = new Aluno(900, "Pedro", 8.5);
            classeDeAlunos.inserir(a4);

            //classeDeAlunos.remover(900);

            Console.WriteLine("Arvore vazia: "+classeDeAlunos.arvoreVazia());
            Console.WriteLine(classeDeAlunos.menorNumeroMatricula().nome);
            Console.WriteLine(classeDeAlunos.contarNumAlunos(a1));
            Console.ReadKey();
        }
    }
}

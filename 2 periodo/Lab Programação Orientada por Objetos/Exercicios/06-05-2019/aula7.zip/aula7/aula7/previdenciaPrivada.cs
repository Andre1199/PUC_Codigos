﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula7
{
    class PrevidenciaPrivada: Conta
    {
        public double taxaDeCarregamento { get; set; }
        public double taxaDeSaque { get; set; }

        static double tarifaBase;
        public PrevidenciaPrivada(Cliente cliente, int numero) : base(cliente, numero)
        {
            this.taxaDeCarregamento = 0.02;
            this.taxaDeSaque = PrevidenciaPrivada.tarifaBase;
        }        
        static PrevidenciaPrivada()
        {
            tarifaBase = 0.019;
        }

        public override void deposita(double valor)
        {
            if(valor > 50000)
                this.Saldo += (valor - (valor * 0.01));
            else
                this.Saldo += (valor - (valor * 0.02));
        }

        public override double saque(double valor)
        {
            double valorRetorno = valor;
            if (this.Saldo >= (valor + (valor * tarifaBase)))
                this.Saldo -= (valor + (valor * tarifaBase));
            else
                return -1;
            return valorRetorno;
        }

        public override double transfere(double valor, Conta destino)
        {
            double valorRetorno = valor;
            if (this.Saldo >= (valor + (valor * tarifaBase)))
            {
                this.Saldo -= (valor + (valor * tarifaBase));
                destino.deposita(valor);
            }
            else
                return -1;
            return valorRetorno;
        }
    }
}

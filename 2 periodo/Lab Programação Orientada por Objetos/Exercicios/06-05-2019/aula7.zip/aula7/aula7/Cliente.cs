﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula7
{
    class Cliente
    {
        public int Numero { get; set; }
        public String Nome { get; set; }

        public Cliente(string nome, int numero)
        {
            this.Nome = nome;
            this.Numero = numero;
        }

    }
}

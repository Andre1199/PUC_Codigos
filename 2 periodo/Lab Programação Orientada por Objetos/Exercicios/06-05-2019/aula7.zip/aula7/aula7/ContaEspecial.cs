﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula7
{
    class ContaEspecial:Conta
    {
        public double limite { get; private set; }
        public CartaoDeCredito[] cartoes;

        public ContaEspecial(Cliente cliente, int numero, CartaoDeCredito [] cards) : base(cliente, numero)
        {
            this.cartoes = cards;
        }
        public override double saque(double valor)
        {
            double valorRetorno = valor;
            if ((this.Saldo+this.limite) >= valor)
                this.Saldo -= valor;
            else
                return -1;
            return valorRetorno;
        }

        public override double transfere(double valor, Conta destino)
        {
            double valorRetorno = valor;
            if ((this.Saldo+this.limite) >= valor )
            {
                this.Saldo -= valor;
                destino.deposita(valor);
            }
            else
                return -1;
            return valorRetorno;
        }
    }
}

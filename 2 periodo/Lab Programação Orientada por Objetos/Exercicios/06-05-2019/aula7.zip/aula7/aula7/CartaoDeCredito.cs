﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula7
{
    class CartaoDeCredito
    {
        public string numeroDoCartao { get; set; }
        public DateTime dataDeValidade { get; set; }
        public double anuidadeCartao { get; set; }

        public CartaoDeCredito(string numeroCard, DateTime dataValid, double anuidade)
        {
            this.numeroDoCartao = numeroCard;
            this.dataDeValidade = dataValid;
            this.anuidadeCartao = anuidade;
        }
    }
}

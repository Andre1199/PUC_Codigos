﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula7
{
    class ContaCorrente:Conta
    {
        public Cliente segundoTitular { get; set; }
        public CartaoDeCredito[] cartoes;
        static double tarifaBase;
        //construtor estático chamado antes da primeira instância ser criada
        static ContaCorrente()
        {
            //tarifa de saque na conta correte de 0,38% sobre o valor
            tarifaBase = 0.038;
        }
        public ContaCorrente(Cliente cliente, int numero, CartaoDeCredito [] cards) : base(cliente, numero)
        {
            this.cartoes = cards;
        }
        //Construtor com parâmetro igual ao construtor da classe base
        public ContaCorrente(Cliente cliente, int numero, Cliente segundoClient, CartaoDeCredito[] cards) : base(cliente, numero)
        {
            this.segundoTitular = segundoTitular;
            this.cartoes = cards;
        }
        //retorna o valor do saque, se não for possível sacar, retorna -1
        public override double saque(double valor)
        {
            double valorRetorno = valor;
            if (this.Saldo >= (valor + (valor * tarifaBase)))
                this.Saldo -= (valor + (valor * tarifaBase));
            else
                return -1;
            return valorRetorno;
        }

        public override double transfere(double valor, Conta destino)
        {
            double valorRetorno = valor;
            if (this.Saldo >= (valor + (valor * tarifaBase)))
            {
                this.Saldo -= (valor + (valor * tarifaBase));
                destino.deposita(valor);
            }
            else
                return -1;
            return valorRetorno;
        }
    }
}

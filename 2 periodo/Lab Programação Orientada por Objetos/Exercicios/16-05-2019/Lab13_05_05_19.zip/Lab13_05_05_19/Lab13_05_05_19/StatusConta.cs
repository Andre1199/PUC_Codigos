﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab13_05_05_19
{
    class StatusConta
    {
        Conta conta;
        public StatusConta(Conta conta1)
        {
            conta = conta1;
        }

        public void ElegivelParaPromoçoes()
        {
            if (this.conta.Saldo > 10000)
                MessageBox.Show("Elegivel para promoções.");

            else
                MessageBox.Show("Elegivel para promoções.");
        }
    }
}

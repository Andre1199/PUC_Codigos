﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_05_05_19
{
    abstract class Operaçao
    {
        public abstract double simularSimples(double deposito, double juros, int meses);
        public abstract double simularComposto(double deposito, double juros, int meses);
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab13_05_05_19
{
    public partial class Form1 : Form
    {
        ContaInvestimento conta = new ContaInvestimento(123);
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double deposito = double.Parse(textBox1.Text);
            double juros = double.Parse(textBox2.Text);
            int meses = int.Parse(textBox3.Text);
            double saldoSimulado = 0;
            object tipo = comboBox1.SelectedItem;
            if (tipo.Equals("Rendimento"))
                if(radioButton1.Checked)
                    saldoSimulado = conta.simulaInvestimentoSimples(new Rendimento(), deposito, juros, meses);
                else if(radioButton2.Checked)
                    saldoSimulado = conta.simulaInvestimentoComposto(new Rendimento(), deposito, juros, meses);
            else if (tipo.Equals("Imposto"))
                if (radioButton1.Checked)
                    saldoSimulado = conta.simulaInvestimentoSimples(new Imposto(), deposito, juros, meses);
                else if(radioButton2.Checked)
                    saldoSimulado = conta.simulaInvestimentoComposto(new Imposto(), deposito, juros, meses);

            MessageBox.Show("Resultado da simulação: " + saldoSimulado);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

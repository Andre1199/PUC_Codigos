﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_05_05_19
{
    abstract class Conta
    {
        public int Numero { get; set; }
        public double Saldo { get; protected set; }

        public Conta(int numero)
        {
            this.Numero = numero;
            this.Saldo = 0;
        }

        public void deposita(double valor)
        {
            this.Saldo += valor;
        }

        public double saque(double valor)
        {
            double valorRetorno = valor;
            if (this.Saldo >= valor)
                this.Saldo -= valor;
            else
                return -1;
            return valorRetorno;
        }

        public double transfere(double valor, Conta destino)
        {
            double valorRetorno = valor;
            if (this.Saldo >= valor)
            {
                this.Saldo -= valor;
                destino.deposita(valor);
            }
            else
                return -1;
            return valorRetorno;

        }

    }
}

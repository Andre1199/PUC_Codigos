﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_05_05_19
{
    class ContaInvestimento:Conta
    {

        private int numero;
        public ContaInvestimento(int numero):base(numero)
        {
            this.numero = numero;
        }
        public double simulaInvestimentoSimples(Operaçao operacao, double deposito, double juros, int meses)
        {
            return operacao.simularSimples(deposito, juros, meses);
        }
        public double simulaInvestimentoComposto(Operaçao operacao, double deposito, double juros, int meses)
        {
            return operacao.simularComposto(deposito, juros, meses);
        }
    }
}

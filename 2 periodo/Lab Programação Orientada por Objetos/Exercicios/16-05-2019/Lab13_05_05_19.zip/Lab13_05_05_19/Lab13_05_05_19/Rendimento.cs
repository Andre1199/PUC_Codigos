﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_05_05_19
{
    class Rendimento:Operaçao
    {
        public override double simularComposto(double deposito, double juros, int meses)
        {
            double aux = 0;

            for (int i = 0; i < meses; i++)
            {
                deposito = deposito + (deposito * (juros * i));
            }

            return deposito;
        }

        public override double simularSimples(double deposito, double juros, int meses)
        {
            return deposito + (deposito * (juros * meses));
        }
    }
}

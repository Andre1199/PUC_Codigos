﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_05_05_19
{
    class ContaPoupança:Conta
    {
        private int numero;
        public ContaPoupança (int numero) : base(numero)
        {
            this.numero = numero;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_05_05_19
{
    class Imposto:Operaçao
    {
        public override double simularSimples(double deposito, double juros, int meses)
        {
            return deposito - (deposito * (juros * meses));
        }

        public override double simularComposto(double deposito, double juros, int meses)
        {
            double aux = 0;

            for (int i = 0; i < meses; i++)
            {
                aux += deposito - (deposito * (juros * meses));
            }

            return aux;
        }
    }
}
